
import java.util.Scanner;

class HotelReservationSystem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String[] roomTypes = {
            "Standard", "Deluxe", "Suite"
        };

        int[] prices = {1000, 2000, 3500};
        boolean[] booked = {false, false, false};

        String[] guestNames = new String[3];
        int[] bookingIds = new int[3];

        int nextBookingId = 101;
        int choice;

        do {
            System.out.println("\n=== HOTEL RESERVATION SYSTEM ===");
            System.out.println("1. Search Rooms");
            System.out.println("2. Book Room");
            System.out.println("3. View Booking");
            System.out.println("4. Cancel Booking");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    System.out.println("\nAvailable Rooms:");
                    for (int i = 0; i < 3; i++) {
                        if (!booked[i]) {
                            System.out.println(
                                roomTypes[i] +
                                " - Rs." + prices[i]
                            );
                        }
                    }
                    break;

                case 2:
                    System.out.println("\nSelect Room:");
                    for (int i = 0; i < 3; i++) {
                        System.out.println(
                            (i + 1) + ". " + roomTypes[i] +
                            " - Rs." + prices[i] +
                            (booked[i] ? " (Booked)" : " (Available)")
                        );
                    }

                    System.out.print("Enter room number (1-3): ");
                    int room = sc.nextInt();
                    sc.nextLine();

                    if (room < 1 || room > 3) {
                        System.out.println("Invalid room number!");
                    } else if (booked[room - 1]) {
                        System.out.println("Room is already booked!");
                    } else {
                        System.out.print("Enter guest name: ");
                        String name = sc.nextLine();

                        System.out.println(
                            "Room price: Rs." + prices[room - 1]
                        );
                        System.out.print(
                            "Confirm simulated payment? (yes/no): "
                        );
                        String payment = sc.nextLine();

                        if (payment.equalsIgnoreCase("yes")) {
                            booked[room - 1] = true;
                            guestNames[room - 1] = name;
                            bookingIds[room - 1] = nextBookingId++;

                            System.out.println(
                                "\nBooking Successful!"
                            );
                            System.out.println(
                                "Booking ID: " +
                                bookingIds[room - 1]
                            );
                            System.out.println(
                                "Guest: " + name
                            );
                            System.out.println(
                                "Room: " + roomTypes[room - 1]
                            );
                            System.out.println(
                                "Payment: Simulated successfully"
                            );
                        } else {
                            System.out.println(
                                "Payment cancelled. Room not booked."
                            );
                        }
                    }
                    break;

                case 3:
                    System.out.print("Enter Booking ID: ");
                    int id = sc.nextInt();

                    boolean found = false;

                    for (int i = 0; i < 3; i++) {
                        if (booked[i] && bookingIds[i] == id) {
                            System.out.println("\nBooking Details:");
                            System.out.println(
                                "Guest: " + guestNames[i]
                            );
                            System.out.println(
                                "Room: " + roomTypes[i]
                            );
                            System.out.println(
                                "Price: Rs." + prices[i]
                            );
                            found = true;
                            break;
                        }
                    }

                    if (!found) {
                        System.out.println("Booking not found!");
                    }
                    break;

                case 4:
                    System.out.print("Enter Booking ID to cancel: ");
                    int cancelId = sc.nextInt();

                    boolean cancelled = false;

                    for (int i = 0; i < 3; i++) {
                        if (booked[i] && bookingIds[i] == cancelId) {
                            booked[i] = false;
                            guestNames[i] = null;
                            bookingIds[i] = 0;

                            System.out.println(
                                "Booking cancelled successfully!"
                            );
                            cancelled = true;
                            break;
                        }
                    }

                    if (!cancelled) {
                        System.out.println("Booking not found!");
                    }
                    break;

                case 5:
                    System.out.println("Thank you for using our hotel!");
                    break;

                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 5);

        sc.close();
    }
}
